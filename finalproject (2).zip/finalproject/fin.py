import serial

ser = serial.Serial('COM3', 9600, timeout = 0, parity=serial.PARITY_EVEN, rtscts=1)

while True:
    val = ser.read()
    print(val)